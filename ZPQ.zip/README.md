# 3D切换及文字拼图

[demo](http://damonowl.himmas.cc/ZPQ)

# 说明

一直对3D充满好奇和图片拼字的方式好奇，恰好工作需要一个类似的demo。

# 所用技术

jq + three.js + create.js

# 功能
* 3D效果的切换变化
* 获取图片进行填充
* 使用获取的图片进行拼logo